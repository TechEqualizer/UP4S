import React, { useState } from 'react';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mail, X, CheckCircle } from "lucide-react";
import { NewsletterSubscriber } from '@/api/entities';

export default function ExitIntentCapture({ isOpen, onClose, onEmailSubmit }) {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      await NewsletterSubscriber.create({
        email: email.trim().toLowerCase(),
        subscription_source: 'exit-intent'
      });
      
      setSubmitted(true);
      setTimeout(() => {
        onEmailSubmit();
      }, 2000);
    } catch (error) {
      console.error("Exit intent subscription error:", error);
      // More user-friendly error handling
      if (error.message?.includes('already exists') || error.message?.includes('duplicate')) {
        alert('This email is already subscribed to our newsletter. Thank you!');
        onEmailSubmit();
      } else {
        alert('There was an error subscribing your email. Please try again or contact us directly.');
      }
    }
    
    setIsSubmitting(false);
  };

  if (submitted) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md">
          <div className="text-center p-6">
            <div className="w-16 h-16 bg-gradient-to-r from-green-100 to-green-200 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            
            <h3 className="text-xl font-bold text-gray-900 mb-3">
              Thank You!
            </h3>
            <p className="text-gray-600 mb-6">
              We've added you to our newsletter. You'll hear inspiring stories from the kids we help.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <div className="text-center p-6">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Mail className="w-8 h-8 text-blue-600" />
          </div>
          
          <h3 className="text-xl font-bold text-gray-900 mb-3">
            Not ready to give today?
          </h3>
          <p className="text-gray-600 mb-6">
            Let us send you a gentle reminder along with inspiring stories from the kids we help.
          </p>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              type="email"
              placeholder="Enter your email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full"
            />
            
            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1"
                disabled={isSubmitting}
              >
                No Thanks
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting || !email.trim()}
                className="flex-1 bg-gradient-to-r from-blue-600 to-blue-700"
              >
                {isSubmitting ? 'Saving...' : 'Remind Me Later'}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}