import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Heart, X, CreditCard, Gift } from "lucide-react";
import ExitIntentCapture from './ExitIntentCapture';
import { createStripeCheckout } from '@/api/functions';

const PRESET_AMOUNTS = [750, 500, 350, 140, 80, 25];

const FEATURED_STORY = {
  name: "Marcus",
  age: 14,
  image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=400&h=400&fit=crop&crop=face",
  story: "Marcus from Detroit is passionate about filmmaking and wants to create a short film about overcoming community challenges and finding hope. Through his story, he hopes to inspire other teens in his neighborhood.",
  location: "Detroit, MI"
};

export default function DonationModal({ isOpen, onClose }) {
  const [amount, setAmount] = useState(140);
  const [customAmount, setCustomAmount] = useState('');
  const [donorInfo, setDonorInfo] = useState({
    name: '',
    email: '',
    dedication_message: ''
  });
  const [fundDesignation, setFundDesignation] = useState('general');
  const [isDedicating, setIsDedicating] = useState(false);
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showExitIntent, setShowExitIntent] = useState(false);
  const [linkedEvent, setLinkedEvent] = useState(null);

  // Global handler for opening the donation modal
  useEffect(() => {
    const handleOpenModal = (e) => {
      if (e.detail?.eventId) {
        setLinkedEvent({ id: e.detail.eventId, title: e.detail.eventTitle });
      }
    };
    window.addEventListener('openDonationModal', handleOpenModal);
    return () => {
      window.removeEventListener('openDonationModal', handleOpenModal);
    };
  }, []);

  const handleAmountSelect = (selectedAmount) => {
    setAmount(selectedAmount);
    setCustomAmount('');
  };

  const handleCustomAmountChange = (value) => {
    setCustomAmount(value);
    setAmount(parseFloat(value) || 0);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsProcessing(true);
    
    try {
      const response = await createStripeCheckout({
        donor_name: donorInfo.name,
        donor_email: donorInfo.email,
        amount: amount,
        donation_type: 'one-time',
        fund_designation: linkedEvent ? 'general' : fundDesignation,
        dedication_message: isDedicating ? donorInfo.dedication_message : '',
        is_anonymous: isAnonymous,
        event_id: linkedEvent ? linkedEvent.id : null,
      });

      if (response.data?.checkout_url) {
        window.location.href = response.data.checkout_url;
      } else {
        const errorMessage = response.data?.error || 'No checkout URL received';
        const errorDetails = response.data?.details ? `Details: ${response.data.details}` : '';
        throw new Error(`${errorMessage} ${errorDetails}`);
      }
    } catch (error) {
      console.error('Donation error:', error);
      alert(`There was an error processing your donation. Please try again.\n\nError: ${error.message}`);
      setIsProcessing(false);
    }
  };

  const handleClose = () => {
    if (!isProcessing) {
      setShowExitIntent(true);
    }
  };

  const finalizeClose = () => {
    setShowExitIntent(false);
    setLinkedEvent(null);
    onClose();
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto p-0">
          <div className="grid md:grid-cols-2 min-h-[600px]">
            {/* Left Panel - Story Card */}
            <div className="relative bg-gradient-to-br from-blue-600 to-blue-800 text-white p-6 md:p-8 flex flex-col justify-between">
              <div className="absolute inset-0 opacity-10">
                <img 
                  src="https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&h=600&fit=crop" 
                  alt="Background pattern"
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="relative z-10">
                <Badge className="mb-6 bg-white/20 text-white border-white/30">
                  Featured Story
                </Badge>
                
                <div className="flex items-center gap-4 mb-6">
                  <img 
                    src={FEATURED_STORY.image}
                    alt={FEATURED_STORY.name}
                    className="w-20 h-20 rounded-full object-cover border-4 border-white/20"
                  />
                  <div>
                    <h3 className="text-2xl font-bold">{FEATURED_STORY.name}</h3>
                    <p className="text-blue-100">Age {FEATURED_STORY.age} • {FEATURED_STORY.location}</p>
                  </div>
                </div>
                
                <p className="text-lg leading-relaxed mb-8 text-blue-50">
                  {FEATURED_STORY.story}
                </p>
              </div>
              
              <div className="relative z-10">
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Gift className="w-5 h-5" />
                    Your Impact
                  </h4>
                  <div className="space-y-2 text-sm">
                    <p>• $750 sponsors a full film project</p>
                    <p>• $350 provides a camera kit for a student</p>
                    <p>• $140 funds a one-on-one mentorship series</p>
                    <p>• $80 supports studio time and equipment</p>
                    <p>• $25 covers basic production supplies</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Panel - Donation Form */}
            <div className="p-6 md:p-8">
              <DialogHeader className="mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Make Your Gift</h2>
                <p className="text-gray-600">Your gift empowers disadvantaged youth through film and arts education</p>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Amount Selection */}
                <div>
                  <Label className="text-base font-semibold mb-3 block">
                    Choose Donation Amount
                  </Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
                    {PRESET_AMOUNTS.map((presetAmount) => (
                      <button
                        key={presetAmount}
                        type="button"
                        onClick={() => handleAmountSelect(presetAmount)}
                        className={`py-3 px-2 sm:px-4 border-2 rounded-lg font-semibold transition-all text-sm sm:text-base ${
                          amount === presetAmount && !customAmount
                            ? 'border-blue-600 bg-blue-50 text-blue-700'
                            : 'border-gray-200 hover:border-gray-300 text-gray-700'
                        }`}
                        aria-pressed={amount === presetAmount && !customAmount}
                      >
                        ${presetAmount}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-700 font-medium">$</span>
                    <Input
                      type="number"
                      placeholder="Custom amount"
                      value={customAmount}
                      onChange={(e) => handleCustomAmountChange(e.target.value)}
                      className="flex-1"
                    />
                  </div>
                </div>

                {/* Donor Information */}
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="donor-name">Full Name *</Label>
                      <Input
                        id="donor-name"
                        required
                        value={donorInfo.name}
                        onChange={(e) => setDonorInfo({...donorInfo, name: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="donor-email">Email *</Label>
                      <Input
                        id="donor-email"
                        type="email"
                        required
                        value={donorInfo.email}
                        onChange={(e) => setDonorInfo({...donorInfo, email: e.target.value})}
                      />
                    </div>
                  </div>

                  {/* Fund Designation */}
                  <div>
                    <Label htmlFor="fund-designation">
                      {linkedEvent ? 'Supporting Event' : 'Designate Funds'}
                    </Label>
                    {linkedEvent ? (
                       <Input
                         id="fund-designation"
                         readOnly
                         disabled
                         value={linkedEvent.title}
                         className="font-semibold"
                       />
                    ) : (
                      <Select value={fundDesignation} onValueChange={setFundDesignation}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="general">General Fund</SelectItem>
                          <SelectItem value="sponsor-wish">Sponsor a Student</SelectItem>
                          <SelectItem value="film-equipment">Film Equipment</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  </div>

                  {/* Dedication */}
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="dedication"
                      checked={isDedicating}
                      onCheckedChange={setIsDedicating}
                    />
                    <Label htmlFor="dedication" className="text-sm">
                      Dedicate this donation in honor or memory of someone
                    </Label>
                  </div>

                  {isDedicating && (
                    <div>
                      <Label htmlFor="dedication-message">Dedication Message</Label>
                      <Textarea
                        id="dedication-message"
                        placeholder="In honor of..."
                        value={donorInfo.dedication_message}
                        onChange={(e) => setDonorInfo({...donorInfo, dedication_message: e.target.value})}
                      />
                    </div>
                  )}

                  {/* Anonymous Option */}
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="anonymous"
                      checked={isAnonymous}
                      onCheckedChange={setIsAnonymous}
                    />
                    <Label htmlFor="anonymous" className="text-sm">
                      Make this donation anonymous
                    </Label>
                  </div>
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={isProcessing || amount <= 0}
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white py-3 text-lg font-semibold"
                >
                  {isProcessing ? (
                    <>Processing...</>
                  ) : (
                    <>
                      <CreditCard className="w-5 h-5 mr-2" />
                      Complete Tax-Deductible Donation
                    </>
                  )}
                </Button>

                <p className="text-xs text-gray-500 text-center">
                  Secure donation processing powered by Stripe • Your information is encrypted and secure
                  <br />Team UP4S is a 501(c)(3) nonprofit (EIN: 92-2415944). All donations are tax-deductible.
                </p>
              </form>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <ExitIntentCapture
        isOpen={showExitIntent}
        onClose={finalizeClose}
        onEmailSubmit={finalizeClose}
      />
    </>
  );
}