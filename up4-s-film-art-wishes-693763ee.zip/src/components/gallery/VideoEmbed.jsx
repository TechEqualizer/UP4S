import React from 'react';

// Utility function to extract video ID and generate thumbnail
export const getVideoThumbnail = (url) => {
  // YouTube
  if (url.includes('youtube.com/watch') || url.includes('youtu.be/')) {
    let videoId = '';
    if (url.includes('youtube.com/watch')) {
      videoId = url.split('v=')[1]?.split('&')[0];
    } else if (url.includes('youtu.be/')) {
      videoId = url.split('youtu.be/')[1]?.split('?')[0];
    }
    if (videoId) {
      return {
        thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
        fallback: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
      };
    }
  }
  
  // Vimeo - requires API call for thumbnail, but we can use a placeholder
  if (url.includes('vimeo.com/')) {
    const videoId = url.split('vimeo.com/')[1]?.split('?')[0];
    if (videoId) {
      return {
        thumbnail: `https://vumbnail.com/${videoId}.jpg`,
        fallback: `https://vumbnail.com/${videoId}_medium.jpg`
      };
    }
  }
  
  return null;
};

export default function VideoEmbed({ url, title }) {
  const getEmbedUrl = (url) => {
    // YouTube
    if (url.includes('youtube.com/watch') || url.includes('youtu.be/')) {
      let videoId = '';
      if (url.includes('youtube.com/watch')) {
        videoId = url.split('v=')[1]?.split('&')[0];
      } else if (url.includes('youtu.be/')) {
        videoId = url.split('youtu.be/')[1]?.split('?')[0];
      }
      if (videoId) {
        return `https://www.youtube.com/embed/${videoId}`;
      }
    }
    
    // Vimeo
    if (url.includes('vimeo.com/')) {
      const videoId = url.split('vimeo.com/')[1]?.split('?')[0];
      if (videoId) {
        return `https://player.vimeo.com/video/${videoId}`;
      }
    }
    
    // Wistia
    if (url.includes('wistia.com/medias/') || url.includes('wistia.net/medias/')) {
      const videoId = url.split('medias/')[1]?.split('?')[0];
      if (videoId) {
        return `https://fast.wistia.net/embed/iframe/${videoId}`;
      }
    }
    
    // If it's already an embed URL or unknown format, return as is
    return url;
  };

  const embedUrl = getEmbedUrl(url);

  return (
    <iframe
      src={embedUrl}
      title={title}
      className="absolute top-0 left-0 w-full h-full"
      frameBorder="0"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
      allowFullScreen
    />
  );
}